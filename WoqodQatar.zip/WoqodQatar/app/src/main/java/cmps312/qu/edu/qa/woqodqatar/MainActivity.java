package cmps312.qu.edu.qa.woqodqatar;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button calculateCost, summaries;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calculateCost = (Button) findViewById(R.id.calculate_cost);
        summaries = (Button) findViewById(R.id.summaries);

        summaries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToSummaries = new Intent(MainActivity.this,SummariesActivity.class);
                startActivity(goToSummaries);
            }
        });

        calculateCost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //go to calculate cost
            }
        });
    }
}
