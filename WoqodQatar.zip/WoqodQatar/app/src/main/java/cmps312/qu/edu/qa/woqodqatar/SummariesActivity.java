package cmps312.qu.edu.qa.woqodqatar;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class SummariesActivity extends AppCompatActivity {

    private ListView summariesList;
    private ArrayList<UserSummary> userSummariesList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summaries);
        summariesList = (ListView) findViewById(R.id.list_summaries);
        userSummariesList = new ArrayList<>();
        summariesList.setAdapter(new SummaryAdapter(SummariesActivity.this,userSummariesList));
    }

    private class SummaryAdapter extends ArrayAdapter<UserSummary>{

        public SummaryAdapter(Context c, ArrayList<UserSummary> summariesList){
            super(c,0,summariesList);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            UserSummary userSummary = getItem(position);

            if(convertView==null){
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.summaties_list_row,null);
            }

            TextView date,fuelType,fuelAmount,price,station;
            date = (TextView) convertView.findViewById(R.id.date);
            fuelType = (TextView) convertView.findViewById(R.id.fuel_type);
            fuelAmount = (TextView) convertView.findViewById(R.id.fuel_amount);
            price = (TextView) convertView.findViewById(R.id.price);
            station = (TextView) convertView.findViewById(R.id.station);

            date.setText(userSummary.getDate().toString());
            fuelType.setText(userSummary.getFuelType());
            fuelAmount.setText(userSummary.getFuelAmount()+"");
            price.setText(userSummary.getPrice()+"");
            station.setText(userSummary.getStation());

            return super.getView(position, convertView, parent);
        }
    }

}
